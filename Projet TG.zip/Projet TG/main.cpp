#include <iostream>
#include "include\Graphe.h"
#include "include/menu.h"

int main()
{
    menu();
//rose la mongole
    return 0;
}







